import React, { useState } from 'react';
import './App.css';

function WeatherCard({ data }) {
  if (!data) return null;
  const { name, country, coord, weather, main, wind, clouds, visibility, sunrise, sunset, dt, timezone } = data;
  const w = weather?.[0] || {};
  const iconUrl = w.icon ? `https://openweathermap.org/img/wn/${w.icon}@2x.png` : null;

  const toLocal = (unix, tz) => {
    if (!unix) return '-';
    const d = new Date((unix + (tz || 0)) * 1000);
    return d.toUTCString().replace('GMT', '');
  }

  return (
    <div className="card">
      <div className="card-header">
        <div>
          <h2>{name}, {country}</h2>
          <p className="muted">{w.main} — {w.description}</p>
        </div>
        <div className="icon-area">
          {iconUrl && <img src={iconUrl} alt={w.description} />}
          <div className="temp">{main?.temp ? `${Math.round(main.temp)}°C` : '-'}</div>
        </div>
      </div>

      <div className="card-body">
        <div className="grid">
          <div><b>Feels like</b><br/>{main?.feels_like ?? '-' }°C</div>
          <div><b>Humidity</b><br/>{main?.humidity ?? '-'}%</div>
          <div><b>Pressure</b><br/>{main?.pressure ?? '-'} hPa</div>
          <div><b>Wind</b><br/>{wind?.speed ?? '-'} m/s</div>
          <div><b>Clouds</b><br/>{clouds?.all ?? '-'}%</div>
          <div><b>Visibility</b><br/>{visibility ?? '-'} m</div>
          <div><b>Coordinates</b><br/>Lat: {coord?.lat ?? '-'}<br/>Lon: {coord?.lon ?? '-'}</div>
          <div><b>Sunrise / Sunset</b><br/>{toLocal(sunrise, timezone)}<br/>{toLocal(sunset, timezone)}</div>
        </div>
      </div>

      <div className="card-footer">
        <a target="_blank" rel="noopener noreferrer" href={`https://www.google.com/maps/search/?api=1&query=${coord?.lat},${coord?.lon}`}>Open in Maps</a>
      </div>
    </div>
  );
}

function App() {
  const [city, setCity] = useState('');
  const [result, setResult] = useState(null);
  const [status, setStatus] = useState('');
  const [raw, setRaw] = useState(null);

  const search = async (e) => {
    e && e.preventDefault();
    if (!city.trim()) { setStatus('Please enter a city name'); return; }
    setStatus('Searching...');
    try {
      const res = await fetch(`/api/weather?city=${encodeURIComponent(city)}`);
      if (!res.ok) {
        const err = await res.json();
        setStatus(`Error: ${err.error || res.statusText}`);
        setResult(null);
        return;
      }
      const body = await res.json();
      setRaw(body.data);
      setResult(body.data);
      setStatus(body.cached ? 'Loaded (cached)' : 'Loaded (fresh)');
    } catch (err) {
      setStatus('Network error');
    }
  };

  return (
    <div className="app">
      <header>
        <h1>Weather Search</h1>
        <p className="muted">Search current weather by city name</p>
      </header>

      <form className="search" onSubmit={search}>
        <input value={city} onChange={e=>setCity(e.target.value)} placeholder="e.g., Pune, Mumbai, London" />
        <button type="submit">Search</button>
      </form>

      <div className="status">{status}</div>

      {result && <WeatherCard data={result} />}

      {raw && (
        <details style={{ marginTop: 16 }}>
          <summary>Show raw API response</summary>
          <pre style={{ maxHeight: 300, overflow: 'auto' }}>{JSON.stringify(raw, null, 2)}</pre>
        </details>
      )}

      <footer>
        <small>Data from OpenWeatherMap • Built locally</small>
      </footer>
    </div>
  );
}

export default App;
